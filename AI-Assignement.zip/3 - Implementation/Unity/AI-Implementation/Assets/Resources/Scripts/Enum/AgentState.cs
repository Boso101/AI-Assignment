﻿public enum AgentState
{
    IDLE,
    PATROL,
    MOVE,


}